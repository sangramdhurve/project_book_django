from django.shortcuts import render, redirect  
from books.froms import booksForm  
from books.models import books  
# Create your views here.  
def emp(request):  
    if request.method == "POST":  
        form = booksForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/show')  
            except:  
                pass  
    else:  
        form = booksForm()  
    return render(request,'index.html',{'form':form})  
def show(request):  
    bookss = books.objects.all()  
    return render(request,"show.html",{'bookss':bookss})  
def edit(request, id):  
    books = books.objects.get(id=id)  
    return render(request,'edit.html', {'books':books})  
def update(request, id):  
    books = books.objects.get(id=id)  
    form = booksForm(request.POST, instance = books)  
    if form.is_valid():  
        form.save()  
        return redirect("/show")  
    return render(request, 'edit.html', {'books': books})  
def destroy(request, id):  
    books = books.objects.get(id=id)  
    books.delete()  
    return redirect("/show")